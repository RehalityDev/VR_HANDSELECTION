~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~ dreamlo - Instant free leadboards.
~
~ http://dreamlo.com
~ Created by: Carmine T. Guida (carmine@carmine.com)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

- Before you do anything, you absolutely must go to dreamlo.com and get your private and public URL.
- Drag the dreamloPrefab into your scene. It must be named exactly "dreamloPrefab"
- Type your public/private codes into the prefab settings.
- If you want to get funky, read the instructions/samples on the dreamlo site. 
- You can store more than scores, you can also store seconds as well as a text string.

NOTE:
- Web requests don't happen automatically! They can take a second or so. All of the functions are coroutines.
- use LoadScores to get the most recent scores. (just ONCE AND WAIT...do not do it every frame)

private url
http://dreamlo.com/lb/g1eC9LEpD0mEo55QhdXM_guslmM40D6E--RAW0MjAPsA
public url
http://dreamlo.com/lb/5a3139116b2b653168e47a36/

private code
g1eC9LEpD0mEo55QhdXM_guslmM40D6E--RAW0MjAPsA
public code
5a3139116b2b653168e47a36