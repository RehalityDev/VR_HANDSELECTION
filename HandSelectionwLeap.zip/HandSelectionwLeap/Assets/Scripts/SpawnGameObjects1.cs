﻿// Eric James McDermott --- 2017 
// this code generates "cubes" at pre-defined locations, 
// then, these locations are randomly sorted and given one at a time,
// the code 'waits' until the spawned object disapears (via contact through "destroyObject.cs") to generate a new cube
// this new cube is generated exactly "secondsBetweenSpawning" later
// additionally, the palmPlacementL and R are recorded
// the code then loads the next level ("Break") or ("Start") once all cubes are contacted

using UnityEngine.UI;
using UnityEngine;
using System.Collections;
using Random = UnityEngine.Random;      //Tells Random to use the Unity Engine random number generator.
using System.Collections.Generic;       //Allows us to use Lists.
using System;
using UnityEngine.SceneManagement;
using System.IO;

public class SpawnGameObjects1 : MonoBehaviour
{

	public GameObject[] spawnObjects; // what presfabs to spawns
	private List<Vector3> gridPositions = new List<Vector3>();   //A list of possible locations to place cubes.
	private float nextSpawnTime;
	public float secondsBetweenSpawning = 2f;
	public static Vector3 palmPlacementL;
	public static Vector3 palmPlacementR;
	public static float startTime;
	public static string cubePlace;
	public static Vector3 cubeVector;
	private float counter;
	public Vector3 positionL;
	public Vector3 positionR;
	private string docs2;
	public static string createFolder2;
	private string dataPath2;
	public string username;


	void Start()
	{
		//nextSpawnTime
		nextSpawnTime = Time.time + secondsBetweenSpawning; 
		//Clear our list gridPositions.
		gridPositions.Clear();

		//hard coding (18) positions to ensure accuracy and positions that you want *float-precision does not allow for 100% accuracy...
		//in this case, mid-line is x = 4

		gridPositions.Add (new Vector3 (1f, 2, 1));

		gridPositions.Add (new Vector3 (2f, 2, 1));

		gridPositions.Add (new Vector3 (3f, 1, 1));
		gridPositions.Add (new Vector3 (3f, 3, 1));

		gridPositions.Add (new Vector3 (4f, 1, 1));
		gridPositions.Add (new Vector3 (4f, 3, 1));

		gridPositions.Add (new Vector3 (5f, 1, 1));
		gridPositions.Add (new Vector3 (5f, 3, 1));

		gridPositions.Add (new Vector3 (6f, 2, 1));

		gridPositions.Add (new Vector3 (7f, 2, 1));

		counter = 1;
		username = GlobalControl.Instance.username;
		docs2 = Environment.GetFolderPath (Environment.SpecialFolder.Desktop);
		createFolder2 = "/trajectory/";
		System.IO.Directory.CreateDirectory (docs2 + createFolder2);
	}

	void WriteToLogFile(string message)
	{
		// CHECK PATH!!!! MUST BE A TRUE PATH! 
		using (System.IO.StreamWriter logFile = new System.IO.StreamWriter ((docs2+createFolder2+username+".txt"), append:true)) {
			logFile.WriteLine (message);
		}
	}
	//RandomPosition returns a random position from our list gridPositions.
	Vector3 RandomPosition()
	{

		//Declare an integer randomIndex, set it's value to a random number between 0 and the count of items in our List gridPositions.
		int randomIndex = Random.Range(0, gridPositions.Count);
		//Declare a variable of type Vector3 called randomPosition, set it's value to the entry at randomIndex from our List gridPositions.
		Vector3 randomPosition = gridPositions[randomIndex];

		//Remove the entry at randomIndex from the list so that it can't be re-used.
		gridPositions.RemoveAt(randomIndex);
		//Return the randomly selected Vector3 position.
		return randomPosition;
	}


	void MakeThingToSpawn ()
	{
		Vector3 randomPosition = RandomPosition();

		// determine which objecst to spawn (in this case, always the cube)
		int objectToSpawn = Random.Range (0, spawnObjects.Length);

		// actually spawn the game objects
	
		GameObject spawnedObject = Instantiate (spawnObjects [objectToSpawn], randomPosition, transform.rotation) as GameObject;
		startTime = Time.time;
		palmPlacementL = GameObject.FindGameObjectWithTag ("ProjectileL").transform.position;
		palmPlacementR = GameObject.FindGameObjectWithTag ("ProjectileR").transform.position;
		// make the parent the spawner so hierarchy doesn't get super messy
		spawnedObject.transform.parent = gameObject.transform;
		cubePlace= (GameObject.FindGameObjectWithTag ("CubeB").transform.position.ToString("F3"));
		cubeVector = GameObject.FindGameObjectWithTag ("CubeB").transform.position;
		//nextSpawnTime
		nextSpawnTime = Time.time + secondsBetweenSpawning; 
		counter = counter + 1;
		Debug.Log (counter);
	}




	// Update is called once per frame
	void FixedUpdate()
	{
		if (!GameObject.FindGameObjectWithTag ("CubeB")) {
			// get next spawn time
			if (Time.time >= nextSpawnTime && gridPositions.Count > 0) {
				// Spawn the game object through function below
				MakeThingToSpawn ();


			}
			if (!GameObject.FindGameObjectWithTag ("CubeB") && gridPositions.Count < 1) {
				SceneManager.LoadScene ("Break");
			}
		} else
			nextSpawnTime = Time.time + secondsBetweenSpawning;
			positionL = GameObject.FindGameObjectWithTag("ProjectileL").transform.position;
			positionR = GameObject.FindGameObjectWithTag("ProjectileR").transform.position;
		WriteToLogFile("Cube number = " + counter + ", TrajectoryL = " + positionL + " , " + Application.loadedLevelName);
		WriteToLogFile("Cube number = " + counter + ", TrajectoryR = " + positionR + " , " + Application.loadedLevelName);

	}
}