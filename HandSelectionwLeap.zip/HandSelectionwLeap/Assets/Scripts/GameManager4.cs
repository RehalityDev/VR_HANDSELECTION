﻿using UnityEngine.UI;
using UnityEngine;
using System.Collections;
using Random = UnityEngine.Random;      //Tells Random to use the Unity Engine random number generator.
using System.Collections.Generic;       //Allows us to use Lists.
using System;
using UnityEngine.SceneManagement;
using System.IO;

public class GameManager4 : MonoBehaviour {

	// make game manager public static so can access this from other scripts
	public static GameManager4 gm;
	public double speed;
	public double totalSpeed;
	public Text mainScoreDisplay;
	public Text totalScoreDisplay;



	// setup the game
	void Start () {
		// get a reference to the GameManager component for use by other scripts
		if (gm == null)
			gm = this.gameObject.GetComponent<GameManager4> ();

		// init scoreboard to 0
		mainScoreDisplay.text = " ";
		totalScoreDisplay.text = " ";
	}
	public void speedUpdate ()
	{
//		mainScoreDisplay.text = DestroyObject4.speed.ToString("F2") + "cm/s";
//		totalScoreDisplay.text = DestroyObject4.totalSpeed.ToString ("F2");
//		//uncomment these if you want real-time feedback of speed

	}


}
