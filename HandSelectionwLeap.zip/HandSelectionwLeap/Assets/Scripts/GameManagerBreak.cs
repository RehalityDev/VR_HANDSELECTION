﻿using UnityEngine.UI;
using UnityEngine;
using System.Collections;
using Random = UnityEngine.Random;      //Tells Random to use the Unity Engine random number generator.
using System.Collections.Generic;       //Allows us to use Lists.
using System;
using UnityEngine.SceneManagement;
using System.IO;

public class GameManagerBreak : MonoBehaviour {

	// make game manager public static so can access this from other scripts
	public static GameManagerBreak gm;
	public Text totalScoreDisplay2;
	public Text totalScoreDisplay3;
	public Text totalScoreDisplay4;
	public Text totalScoreDisplay5;
	private string docs;
	public static string createFolder;
	private string dataPath;
	public string username;


	// setup the game
	void Start () {
		// get a reference to the GameManager component for use by other scripts
		if (gm == null)
			gm = this.gameObject.GetComponent<GameManagerBreak> ();

		if (DestroyObject2.totalSpeed > 0) {
			totalScoreDisplay2.text = "Level 2 Score = " + DestroyObject2.totalSpeed.ToString ("F2");
		} else
			totalScoreDisplay2.text = " ";

		if (DestroyObject3.totalSpeed > 0) {
			totalScoreDisplay3.text = "Level 3 Score = " + DestroyObject3.totalSpeed.ToString ("F2");
		} else
			totalScoreDisplay3.text = " ";
		
		if (DestroyObject4.totalSpeed > 0) {
			totalScoreDisplay4.text = "Level 4 Score = " + DestroyObject4.totalSpeed.ToString ("F2");
		} else
			totalScoreDisplay4.text = " ";
		
		if (DestroyObject5.totalSpeed > 0) {
			totalScoreDisplay5.text = "Level 5 Score = " + DestroyObject5.totalSpeed.ToString ("F2");
		} else
			totalScoreDisplay5.text = " ";

		if (DestroyObject2.totalSpeed > 0 & DestroyObject3.totalSpeed > 0 & DestroyObject4.totalSpeed > 0 & DestroyObject5.totalSpeed > 0) {
			username = GlobalControl.Instance.username;
			docs = Environment.GetFolderPath (Environment.SpecialFolder.Desktop);
			createFolder = "/leaderboard/";
			System.IO.Directory.CreateDirectory (docs + createFolder);
			WriteToLogFile("username: " + username + ", Level 1 Score = " + DestroyObject1.totalSpeed + ", Level 2 Score = " + DestroyObject2.totalSpeed + ", Level 3 Score = " + DestroyObject3.totalSpeed + ", Level 4 Score = " + DestroyObject4.totalSpeed + ", Level 5 Score = " + DestroyObject5.totalSpeed);

		}

	}
		void WriteToLogFile(string message)
		{
			// CHECK PATH!!!! MUST BE A TRUE PATH! 
			using (System.IO.StreamWriter logFile = new System.IO.StreamWriter ((docs+createFolder+"leaders.txt"), append:true)) {
				logFile.WriteLine (message);
			}

		}


	}
