﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour {
	
	[SerializeField]
	private GameObject btn;

	[SerializeField]
	private InputField input;

	[SerializeField]
	private Text text;

	public string nextLevelToLoad;

	void Awake () {
		DontDestroyOnLoad (GameObject.FindGameObjectWithTag("GameController"));
	}

	public void GetInput(string username){
		Debug.Log (username);
		GlobalControl.Instance.username = username;
		SceneManager.LoadScene(nextLevelToLoad);
	}
		


	}
		