﻿using UnityEngine;
using System.Collections;
using Random = UnityEngine.Random;      //Tells Random to use the Unity Engine random number generator.
using System.Collections.Generic;       //Allows us to use Lists.
using System;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class SpawnGameObjectsOld: MonoBehaviour
{
   
    public int columns ;                                         //Number of columns.
    public int rows ;  
	public int depth ;//Number of rows.
	public GameObject[] spawnObjects; // what presfabs to spawns
    private List<Vector3> gridPositions = new List<Vector3>();   //A list of possible locations to place cubes.
	private float nextSpawnTime;
	public float secondsBetweenSpawning = 2f;
	public static Vector3 palmPlacementL;
	public static Vector3 palmPlacementR;
	public static float startTime;
	// Use this for initialization
     [Serializable]
    public class Count
    {
       public int minimum;             //Minimum value for our Count class.
        public int maximum;             //Maximum value for our Count class.


       // Assignment constructor.
        public Count(int min, int max)
       {
            minimum = min;
            maximum = max;
        }
    }


    void Start()
    {
		//nextSpawnTime
		nextSpawnTime = Time.time + secondsBetweenSpawning; 
        //Clear our list gridPositions.
        gridPositions.Clear();

        //Loop through x axis (columns).
        for (int x = 1; x <= columns ; x++)
        {
            //Within each column, loop through y axis (rows).
            for (int y = 1; y <= rows; y++)
            {
				for (int z = 1; z <= depth; z++)
				{
                //At each index add a new Vector3 to our list with the x and y coordinates of that position.
				gridPositions.Add(new Vector3(x, y, z));
            }
           }
    	}
	}

    //RandomPosition returns a random position from our list gridPositions.
    Vector3 RandomPosition()
    {
       
        //Declare an integer randomIndex, set it's value to a random number between 0 and the count of items in our List gridPositions.
        int randomIndex = Random.Range(0, gridPositions.Count);

        //Declare a variable of type Vector3 called randomPosition, set it's value to the entry at randomIndex from our List gridPositions.
        Vector3 randomPosition = gridPositions[randomIndex];

        //Remove the entry at randomIndex from the list so that it can't be re-used.
        gridPositions.RemoveAt(randomIndex);

        //Return the randomly selected Vector3 position.
        return randomPosition;
    }

	// Update is called once per frame
	
	void MakeThingToSpawn ()
	{
        Vector3 randomPosition = RandomPosition();

		// determine which object to spawn (in this case, always the cube)
		int objectToSpawn = Random.Range (0, spawnObjects.Length);

		// actually spawn the game objects
		GameObject spawnedObject = Instantiate (spawnObjects [objectToSpawn], randomPosition, transform.rotation) as GameObject;
		startTime = Time.time;
		// make the parent the spawner so hierarchy doesn't get super messy
		spawnedObject.transform.parent = gameObject.transform;

		//nextSpawnTime
		nextSpawnTime = Time.time + secondsBetweenSpawning; 

	}
    void Update()
	{
		if (!GameObject.FindGameObjectWithTag ("CubeB")) {
			// get next spawn time
			if (Time.time >= nextSpawnTime && gridPositions.Count > 0) {
				// Spawn the game object through function below
				MakeThingToSpawn ();
				palmPlacementL = GameObject.FindGameObjectWithTag("ProjectileL").transform.position;
				palmPlacementR = GameObject.FindGameObjectWithTag("ProjectileR").transform.position;
				Debug.Log (palmPlacementR);
				Debug.Log (palmPlacementL);
			}
			if (!GameObject.FindGameObjectWithTag ("CubeB") && gridPositions.Count < 1) {
				SceneManager.LoadScene ("Break");
			}
		} else
			nextSpawnTime = Time.time + secondsBetweenSpawning;
	}
 }

//void Update()
//{
//	if (!GameObject.FindGameObjectWithTag ("CubeB")) {
//		StartCoroutine (HandleIt ());
//	}
//}
//private IEnumerator HandleIt()
//{
//	yield return new WaitForSeconds (2.0f);
//	MakeThingToSpawn ();
//
//	// determine the next time to spawn the object
//	//	nextSpawnTime = Time.time+secondsBetweenSpawning;
//}
////