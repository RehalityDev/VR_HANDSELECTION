﻿// Eric James McDermott --- 2017
// This code writes data (cube spawn position, palm position on cube spawn, timing, level) to a file in the "data" folder on the desktop
// !MUST CHECK PATH!
// The code detects collisions between the 'cube' and the 'hand' 
// once a collision is detected, it records the aforementioned data
using UnityEngine.UI;
using UnityEngine;
using System.Collections;
using System;
using System.IO;

public class DestroyObject3 : MonoBehaviour
{
	
	// target impact on game
	public enum whichHandContact {Both}
	public whichHandContact Hand = whichHandContact.Both;
	public string username;
	public static float contactTime; 
	private string docs;
	public static string createFolder;
	private string dataPath;
	public static float timeDiff; 
	public static Vector3 reachVector;
	public static double reachDistance;
	public static double speed = 0.00;
	public static Text DisplaySpeed;
	public static double totalSpeed = 0.00;

	void Start ()
	{
		username = GlobalControl.Instance.username;
		docs = Environment.GetFolderPath (Environment.SpecialFolder.Desktop);
		createFolder = "/data/";
		System.IO.Directory.CreateDirectory (docs + createFolder);
	}
	void WriteToLogFile(string message)
	{
		// CHECK PATH!!!! MUST BE A TRUE PATH! 
		using (System.IO.StreamWriter logFile = new System.IO.StreamWriter ((docs+createFolder+username+".txt"), append:true))  {
			logFile.WriteLine (message);
		}
	}

	// when collided with another gameObject
	void OnCollisionEnter (Collision newCollision)
	{
		switch(Hand)
		{
		case whichHandContact.Both:
			if (newCollision.gameObject.tag == "ProjectileL") {
				contactTime = Time.time;
				timeDiff = contactTime - SpawnGameObjects3.startTime;
				reachVector = (SpawnGameObjects3.palmPlacementL - SpawnGameObjects3.cubeVector);
				reachDistance = Math.Sqrt((reachVector.x * reachVector.x) + (reachVector.y * reachVector.y) + (reachVector.z * reachVector.z));
				speed = (reachDistance / timeDiff) * 10;
				totalSpeed = speed + totalSpeed;
				GameManager3.gm.speedUpdate();
				WriteToLogFile ("LeftHandTransform= "+ SpawnGameObjects3.palmPlacementL + " , CubeTransform= " + SpawnGameObjects3.cubePlace + " , startTime= "  + SpawnGameObjects3.startTime + " , contactTime= " + contactTime + " , " + Application.loadedLevelName);
				Destroy (gameObject);
			}
			if (newCollision.gameObject.tag == "ProjectileR") {
				contactTime = Time.time;
				timeDiff = contactTime - SpawnGameObjects3.startTime;
				reachVector = (SpawnGameObjects3.palmPlacementR - SpawnGameObjects3.cubeVector);
				reachDistance = Math.Sqrt((reachVector.x * reachVector.x) + (reachVector.y * reachVector.y) + (reachVector.z * reachVector.z));
				speed = (reachDistance / timeDiff) * 10;
				totalSpeed = speed + totalSpeed;
				GameManager3.gm.speedUpdate();
				WriteToLogFile ("RightHandTransform= "+ SpawnGameObjects3.palmPlacementR + " , CubeTransform= " + SpawnGameObjects3.cubePlace + " , startTime= "  + SpawnGameObjects3.startTime + " , contactTime= " + contactTime + " , " + Application.loadedLevelName);
				Destroy (gameObject);

			}
			break;
		}	
	}
}