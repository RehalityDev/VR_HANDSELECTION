﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using System.IO;
using System;
using System.Collections.Generic;
using System.Text;
using System.Net;


public class oldDestroyObject : MonoBehaviour
{
    Ray ray;
    RaycastHit hit;
   // StreamWriter outputFile = new StreamWriter("C:\\Users\\Kinect Workstation\\Desktop\\Eric\\WriteLines.txt", true);

    void Update()
    {
        {
            ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            if (Physics.Raycast(ray, out hit) && Input.GetMouseButtonDown(0))
            {
                if (hit.collider.tag == "Cube")
                {
                    Debug.Log("Left" + GameObject.FindGameObjectWithTag("Cube").transform.position);
                  //  outputFile.WriteLine("Left" + GameObject.FindGameObjectWithTag("Cube").transform.position);
                  //  outputFile.Close();
                    Destroy(gameObject);

                }
                if (Physics.Raycast(ray, out hit) && Input.GetMouseButtonDown(1))
                {
                    if (hit.collider.tag == "Cube")
                    {
                        Debug.Log("Right" + GameObject.FindGameObjectWithTag("Cube").transform.position);
                    //    outputFile.WriteLine("Right" + GameObject.FindGameObjectWithTag("Cube").transform.position);
                      //  outputFile.Close();
                        Destroy(gameObject);
                    }
                }
            }
        }
    }
}
