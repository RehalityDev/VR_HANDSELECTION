﻿// Eric James McDermott --- 2017
// This code writes data (cube spawn position, palm position on cube spawn, timing, level) to a file in the "data" folder on the desktop
// !MUST CHECK PATH!
// The code detects collisions between the 'cube' and the 'hand' 
// once a collision is detected, it records the aforementioned data

using UnityEngine.UI;
using UnityEngine;
using System.Collections;
using System;
using System.IO;

public class DetectMovement1 : MonoBehaviour
{

	// target impact on game
	public enum whichHandContact {Both}
	public whichHandContact Hand = whichHandContact.Both;
	public static float contactTime; 
	public static Vector3 palmPlacementL;
	public static Vector3 palmPlacementR;
	private bool counter;
	void Start ()

	{
		counter = false;
	}
	void GetTime ()
	{
		if (GameObject.FindGameObjectWithTag ("CubeB") != null && counter == true)
			contactTime = Time.time;
	}

	// when collided with another gameObject
	void OnCollisionEnter (Collision newCollision)
	{
		switch(Hand)
		{
		case whichHandContact.Both:
			if (newCollision.gameObject.tag == "ProjectileL" & GameObject.FindGameObjectWithTag ("CubeB") != null) {
			//	contactTime = Time.time;
				palmPlacementL = GameObject.FindGameObjectWithTag ("ProjectileL").transform.position;
				counter = true;
			}
			if (newCollision.gameObject.tag == "ProjectileR" & GameObject.FindGameObjectWithTag ("CubeB") != null) {
			//	contactTime = Time.time;
				palmPlacementR = GameObject.FindGameObjectWithTag ("ProjectileR").transform.position;
				counter = true;
			}
			break;
		}	
	}
	void FixedUpdate()
	{
		GetTime ();
		counter = false;
	}
}